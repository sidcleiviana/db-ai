import requests
import json
import os

# Pegando a chave da API da variável de ambiente
API_KEY = os.getenv("OPENROUTER_API_KEY")

# Verifica se a chave foi definida
if not API_KEY:
    raise ValueError("❌ Erro: A variável de ambiente OPENROUTER_API_KEY não está definida!")

# URL da API do OpenRouter
url = "https://openrouter.ai/api/v1/chat/completions"

# Cabeçalhos da requisição
headers = {
    "Authorization": f"Bearer {API_KEY}",
    "HTTP-Referer": "http://localhost",  # Se for um app web, mude para o domínio correto
    "X-Title": "DB-TALK-AI",
    "Content-Type": "application/json"
}

# Corpo da requisição de teste
data = {
    "model": "openai/gpt-4o",  # Pode escolher outro modelo disponível no OpenRouter
    "messages": [
        {"role": "system", "content": "Você é um assistente SQL."},
        {"role": "user", "content": "Liste os 10 clientes que mais compraram nos últimos 3 meses."}
    ]
}

# Fazendo a requisição
response = requests.post(url, headers=headers, json=data)

# Exibindo a resposta da API
print(response.json())
