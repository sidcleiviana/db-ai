import os
print(os.getenv("OPENROUTER_API_KEY"))
